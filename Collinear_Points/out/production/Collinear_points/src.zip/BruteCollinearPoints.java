import edu.princeton.cs.algs4.StdOut;

import java.util.Arrays;
import java.util.Comparator;

public class BruteCollinearPoints {
    private LineSegment[] segments;
    private int numberSegments;

    // finds all line segments containing 4 points
    public BruteCollinearPoints(Point[] points) {

        if (points == null)
            throw new IllegalArgumentException("Not null argument");
        for (int i = 0; i < points.length; i++)
            if (points[i] == null)
                throw new IllegalArgumentException("Not allowed nulls in array");
        Arrays.sort(points);
        for (int i = 0; i < points.length; i++) {
            if (i < points.length - 1)
                if (points[i].compareTo(points[i + 1]) == 0)
                    throw new IllegalArgumentException("Duplicated points not allowed");
        }


        segments = new LineSegment[1];
        numberSegments = 0;
        for (int i = 0; i < points.length - 3; i++) {
            for (int j = i + 1; j < points.length - 2; j++) {
                for (int k = j + 1; k < points.length - 1; k++) {
                    for (int l = k + 1; l < points.length; l++) {
                        Comparator<Point> comp = points[i].slopeOrder();
                        if (comp.compare(points[j], points[k]) == 0 && comp.compare(points[k], points[l]) == 0) {
                            //StdOut.println(points[i] + " " + points[j] + " " + points[k] + " " + points[l]);
                            //StdOut.println(points[i].slopeTo(points[j]) + "_" + points[i].slopeTo(points[k]) + "_" + points[i].slopeTo(points[l]));
                            segments[numberSegments++] = new LineSegment(points[i], points[l]);
                            if (numberSegments == segments.length)
                                resize(segments.length * 2);
                        }
                    }
                }
            }
        }
        resize(numberSegments);
    }

    private void resize(int capacity) {
        LineSegment[] copy = new LineSegment[capacity];
        int to = Math.min(segments.length, capacity);
        for (int i = 0; i < to; i++) {
            copy[i] = segments[i];
        }
        segments = copy;
    }

    // the number of line segments
    public int numberOfSegments() {
        return numberSegments;
    }

    // the line segments
    public LineSegment[] segments() {
        return segments;
    }

    public static void main(String[] args) {
        int[] xs = {1, 2, 3, 4, 3, 6, 9, 12, 7, 7, 7, 7, 1, 2, 3, 4};
        int[] ys = {1, 2, 3, 4, 1, 2, 3, 4, 5, 3, 4, 1, 9, 9, 9, 9};
        Point[] points = new Point[xs.length];
        for (int i = 0; i < xs.length; i++) {
            points[i] = new Point(xs[i], ys[i]);
            //points[i].draw();
            StdOut.print(points[i] + " ");
        }
        BruteCollinearPoints bcp = new BruteCollinearPoints(points);
        StdOut.println("\n" + bcp.numberSegments);
        LineSegment[] segments = bcp.segments();
        for (int i = 0; i < segments.length; i++) {
            //segments[i].draw();
            StdOut.println(segments[i]);
        }
    }
}
