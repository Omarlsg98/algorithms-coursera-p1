import edu.princeton.cs.algs4.StdDraw;
import edu.princeton.cs.algs4.StdOut;

import java.util.Arrays;

public class FastCollinearPoints {
    private LineSegment[] segments;
    private int numberSegments;
    private Point[][] segmios;

    // finds all line segments containing 4 or more points
    public FastCollinearPoints(Point[] points) {
        if (points == null)
            throw new IllegalArgumentException("Not null argument");
        for (int i = 0; i < points.length; i++)
            if (points[i] == null)
                throw new IllegalArgumentException("Not allowed nulls in array");
        Arrays.sort(points);
        for (int i = 0; i < points.length; i++) {
            if (i < points.length - 1)
                if (points[i].compareTo(points[i + 1]) == 0)
                    throw new IllegalArgumentException("Duplicated points not allowed");
        }

        // Here begins the algorithm
        segmios = new Point[1][2];
        numberSegments = 0;

        Point[] pointsCopy = new Point[points.length];
        for (int i = 0; i < points.length; i++)
            pointsCopy[i] = points[i];

        for (int i = 0; i < points.length; i++) {
            Arrays.sort(pointsCopy, points[i].slopeOrder());
            int count = 0;
            Point max = points[i];
            Point min = points[i];
            //StdOut.println("\n---------------------->" + points[i]);
            for (int j = 2; j < pointsCopy.length; j++) {
                // StdOut.println(points[i].slopeTo(pointsCopy[j]) + "-->" + pointsCopy[j]);
                if (points[i].slopeTo(pointsCopy[j - 1]) == points[i].slopeTo(pointsCopy[j])) {
                    count++;
                    if (min.compareTo(pointsCopy[j]) > 0) {
                        min = pointsCopy[j];
                    } else if (max.compareTo(pointsCopy[j]) < 0) {
                        max = pointsCopy[j];
                    }
                    if (count == 1) {
                        if (min.compareTo(pointsCopy[j - 1]) > 0) {
                            min = pointsCopy[j - 1];
                        } else if (max.compareTo(pointsCopy[j - 1]) < 0) {
                            max = pointsCopy[j - 1];
                        }
                    }
                } else {
                    if (count > 0) {
                        //StdOut.println("Count " + count);
                        if (count > 1) {
                            addSegment(min, max);
                            break;
                        }
                        count = 0;
                        min = points[i];
                        max = points[i];
                    }
                }
            }
            if (count > 1) {
                //StdOut.println("Count " + count);
                addSegment(min, max);
            }
        }
        createSegments();
    }

    private void createSegments() {
        segments = new LineSegment[numberSegments];
        for (int i = 0; i < numberSegments; i++) {
            segments[i] = new LineSegment(segmios[i][0], segmios[i][1]);
        }
    }

    private void addSegment(Point point, Point point1) {
        for (int i = 0; i < numberSegments; i++) {
            if (point.compareTo(segmios[i][0]) == 0 && point1.compareTo(segmios[i][1]) == 0)
                return;
        }
        segmios[numberSegments][0] = point;
        segmios[numberSegments++][1] = point1;
        if (numberSegments == segmios.length)
            resize(segmios.length * 2);
    }

    private void resize(int capacity) {
        Point[][] copymio = new Point[capacity][2];
        int to = segmios.length;
        for (int i = 0; i < to; i++) {
            copymio[i][0] = segmios[i][0];
            copymio[i][1] = segmios[i][1];
        }
        segmios = copymio;
    }

    // the number of line segments
    public int numberOfSegments() {
        return numberSegments;
    }

    // the line segments
    public LineSegment[] segments() {
        return segments;
    }

    public static void main(String[] args) {
        int[] xs = {1, 2, 3, 4, 5, 6, 3, 6, 9, 12, 7, 7, 7, 7, 1, 2, 3, 4};
        int[] ys = {1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 3, 4, 1, 9, 9, 9, 9};
        Point[] points = new Point[xs.length];

        StdDraw.enableDoubleBuffering();
        StdDraw.setXscale(0, 10);
        StdDraw.setYscale(0, 10);
        StdDraw.setPenRadius(0.01);
        for (int i = 0; i < xs.length; i++) {
            points[i] = new Point(xs[i], ys[i]);
            points[i].draw();
            StdOut.print(points[i] + " ");
        }
        StdDraw.show();

        StdDraw.setPenRadius();
        FastCollinearPoints fcp = new FastCollinearPoints(points);
        StdOut.println("\n" + fcp.numberSegments);
        LineSegment[] segments = fcp.segments();
        for (int i = 0; i < segments.length; i++) {
            segments[i].draw();
            StdOut.println(segments[i]);
        }
        StdDraw.show();
    }
}
