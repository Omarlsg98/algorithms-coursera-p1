import edu.princeton.cs.algs4.MinPQ;
import edu.princeton.cs.algs4.StdOut;

import java.util.Comparator;
import java.util.Iterator;

public class Solver {
    private SearchNode solution;
    private Board initial;

    private class SearchNode {
        SearchNode previousNode;
        Board board;
        int movements;
        int priority;
        int manhattan;

        SearchNode(int movements, Board board, SearchNode previousNode) {
            this.movements = movements;
            this.board = board;
            this.previousNode = previousNode;
            this.manhattan = board.manhattan();
            priority = manhattan + this.movements;
        }

    }

    private static class ByPriority implements Comparator<SearchNode> {
        public int compare(SearchNode a, SearchNode b) {
            int diff = a.priority - b.priority;
            return Integer.compare(diff, 0);
        }
    }

    // find a solution to the initial board (using the A* algorithm)
    public Solver(Board initial) {
        if (initial == null)
            throw new IllegalArgumentException("Not null");
        this.initial = initial;
    }

    // is the initial board solvable? (see below)
    public boolean isSolvable() {
        MinPQ<SearchNode> pq = new MinPQ<>(new ByPriority());
        SearchNode actual = new SearchNode(0, initial, null);
        pq.insert(actual);

        MinPQ<SearchNode> pqMirror = new MinPQ<>(new ByPriority());
        SearchNode actualMirror = new SearchNode(0, initial.twin(), null);
        pqMirror.insert(actualMirror);
        while (true) {
            actual = pq.delMin();
            actualMirror = pqMirror.delMin();
            if (actual.board.isGoal()) {
                solution = actual;
                return true;
            }
            if (actualMirror.board.isGoal())
                return false;
            for (Board n : actual.board.neighbors()) {
                if (!n.equals(actual.board))
                    pq.insert(new SearchNode(actual.movements + 1, n, actual));
            }
            for (Board n : actualMirror.board.neighbors()) {
                if (!n.equals(actualMirror.board))
                    pqMirror.insert(new SearchNode(actualMirror.movements + 1, n, actualMirror));
            }
        }
    }

    // min number of moves to solve initial board
    public int moves() {
        return solution.movements;
    }

    // sequence of boards in a shortest solution
    public Iterable<Board> solution() {
        return new Iterable<Board>() {
            @Override
            public Iterator<Board> iterator() {
                return new SolutionIterator(solution);
            }
        };
    }

    private class SolutionIterator implements Iterator<Board> {
        Board[] steps;
        int actualStep = 0;

        public SolutionIterator(SearchNode solution) {
            steps = new Board[solution.movements + 1];
            SearchNode actual = solution;
            for (int i = steps.length - 1; i >= 0; i--) {
                steps[i] = actual.board;
                actual = actual.previousNode;
            }
        }

        // Checks if the next element exists
        public boolean hasNext() {
            return actualStep < steps.length;
        }

        // moves the cursor/iterator to next element
        public Board next() {
            Board b = steps[actualStep++];
            return b;
        }

        // Used to remove an element. Implement only if needed
        public void remove() {
            throw new UnsupportedOperationException();
        }
    }

    // test client (see below)
    public static void main(String[] args) {
        int[][] tiles = {{0, 1, 3}, {4, 2, 5}, {7, 8, 6}};
        Board initial = new Board(tiles);

        // solve the puzzle
        Solver solver = new Solver(initial);
        // print solution to standard output
        if (!solver.isSolvable())
            StdOut.println("No solution possible");
        else {
            StdOut.println("Minimum number of moves = " + solver.moves());
            for (Board board : solver.solution())
                StdOut.println(board);
        }
    }

}
