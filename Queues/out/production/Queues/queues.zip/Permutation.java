import edu.princeton.cs.algs4.StdIn;
import edu.princeton.cs.algs4.StdOut;


public class Permutation {
    public static void main(String[] args) {
        int k = Integer.parseInt(args[0]);
        RandomizedQueue rq = new RandomizedQueue();
        while (StdIn.hasNextLine()) {
            String c = StdIn.readString();
            rq.enqueue(c);
        }
        for (Object c : rq) {
            StdOut.println(c);
            k--;
            if (k < 1) break;
        }
    }
}
